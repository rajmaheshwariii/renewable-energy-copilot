"""
Configuration for the Renewable Energy Risk Engine.

This file contains:
1. Risk component weights
2. Risk-level thresholds
3. Condition thresholds
4. Battery thresholds
5. Uncertainty thresholds
6. Default values

The actual risk calculations are implemented in risk_engine.py.
"""


# ============================================================
# 1. RISK COMPONENT WEIGHTS
# ============================================================
#
# Total must equal 1.0
#
# Energy shortage is given the highest weight because failure
# to meet demand is the most important operational risk.
#
DEFAULT_BATTERY_SOC_PCT = 50.0
DEFAULT_BACKUP_AVAILABLE = True
DEFAULT_BACKUP_CAPACITY_KW = 0.0
DEFAULT_GRID_EXPORT_AVAILABLE = True
DEFAULT_GRID_EXPORT_LIMIT_KW = 0.0
RISK_WEIGHTS = {
    "energy": 0.40,
    "battery": 0.20,
    "uncertainty": 0.15,
    "backup": 0.15,
    "grid": 0.10,
}


# ============================================================
# 2. RISK SCORE LEVELS
# ============================================================
#
# Final score:
#
# 0–25   -> LOW
# 26–50  -> MODERATE
# 51–75  -> HIGH
# 76–100 -> CRITICAL
#

RISK_THRESHOLDS = {
    "low": 25,
    "moderate": 50,
    "high": 75,
}


# ============================================================
# 3. SHORTAGE / SURPLUS THRESHOLD
# ============================================================
#
# We don't classify a tiny difference between generation and
# demand as a shortage or surplus.
#
# Example:
#
# Demand = 10,000 kW
# Forecast = 9,950 kW
#
# Difference is only 0.5%, so this should not immediately
# become a shortage alert.
#

SHORTAGE_THRESHOLD_PCT = 10.0
SURPLUS_THRESHOLD_PCT = 10.0


# ============================================================
# 4. BATTERY STATE OF CHARGE THRESHOLDS
# ============================================================

BATTERY_THRESHOLDS = {
    "critical": 20.0,
    "low": 30.0,
    "healthy": 60.0,
    "high": 80.0,
}


# ============================================================
# 5. FORECAST UNCERTAINTY THRESHOLDS
# ============================================================
#
# uncertainty_pct represents estimated forecast uncertainty.
#
# These values can later be calibrated using actual model error.
#

UNCERTAINTY_THRESHOLDS = {
    "low": 5.0,
    "moderate": 10.0,
    "high": 20.0,
    "critical": 30.0,
}


# ============================================================
# 6. UNCERTAINTY RISK SCALING
# ============================================================
#
# 30% uncertainty -> approximately 100 risk points.
#
# Example:
#
# 5%  -> 16.7
# 10% -> 33.3
# 20% -> 66.6
# 30% -> 100
#

MAX_UNCERTAINTY_FOR_100_RISK = 30.0


# ============================================================
# 7. BACKUP RISK VALUES
# ============================================================

BACKUP_RISK = {
    "available_and_sufficient": 20.0,
    "available_but_insufficient": 80.0,
    "unavailable": 100.0,
}


# ============================================================
# 8. GRID EXPORT RISK VALUES
# ============================================================

GRID_RISK = {
    "normal": 20.0,
    "export_limit_exceeded": 80.0,
    "export_unavailable": 100.0,
}


# ============================================================
# 9. DEFAULT UNCERTAINTY
# ============================================================

DEFAULT_UNCERTAINTY_PCT = 10.0


# ============================================================
# 10. DEFAULT OPERATIONAL VALUES
# ============================================================

DEFAULT_DEMAND_KW = 0.0
DEFAULT_BATTERY_SOC_PCT = 50.0

DEFAULT_BACKUP_AVAILABLE = True
DEFAULT_BACKUP_CAPACITY_KW = 0.0

DEFAULT_GRID_EXPORT_AVAILABLE = True
DEFAULT_GRID_EXPORT_LIMIT_KW = 0.0


# ============================================================
# 11. SCORE CLAMPING
# ============================================================

MIN_RISK_SCORE = 0.0
MAX_RISK_SCORE = 100.0


# ============================================================
# 12. HELPER FUNCTION
# ============================================================

def validate_weights():

    total = sum(RISK_WEIGHTS.values())

    if abs(total - 1.0) > 1e-6:

        raise ValueError(
            f"Risk weights must sum to 1.0, but got {total}"
        )

    return True

validate_weights()