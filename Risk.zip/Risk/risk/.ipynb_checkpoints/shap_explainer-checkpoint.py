
"""
SHAP Explainability Module

This module explains the predictions made by the
renewable energy forecasting model.

Output:
    - Feature
    - Feature value
    - SHAP value
    - Direction of impact
"""

import joblib
import shap
import pandas as pd
import numpy as np


class RenewableSHAPExplainer:

    def __init__(
        self,
        model_path,
        features_path
    ):

        # Load trained forecasting model
        self.model = joblib.load(
            model_path
        )

        # Load feature list used during training
        self.features = joblib.load(
            features_path
        )

        # Create SHAP TreeExplainer
        self.explainer = shap.TreeExplainer(
            self.model
        )

    def prepare_input(self, X):
        """
        Convert input into a DataFrame and ensure
        feature order matches the trained model.
        """

        if isinstance(X, dict):

            X = pd.DataFrame([X])

        elif isinstance(X, pd.Series):

            X = X.to_frame().T

        elif not isinstance(X, pd.DataFrame):

            X = pd.DataFrame(X)

        # If feature list exists, enforce feature order
        if self.features is not None:

            feature_names = self.features

            # Some saved feature files may contain
            # a dictionary instead of a list.
            if isinstance(
                self.features,
                dict
            ):

                feature_names = (
                    self.features.get(
                        "features"
                    )
                    or
                    self.features.get(
                        "feature_names"
                    )
                )

            if feature_names is not None:

                # Add missing features as zero
                for feature in feature_names:

                    if feature not in X.columns:

                        X[feature] = 0.0

                # Keep only training features
                X = X[feature_names]

        return X

    def explain(self, X):

        """
        Return raw SHAP values.
        """

        X = self.prepare_input(X)

        shap_values = (
            self.explainer.shap_values(X)
        )

        return shap_values

    def generate_explanation(self, X):

        """
        Generate human-readable feature explanations.
        """

        X = self.prepare_input(X)

        shap_values = (
            self.explainer.shap_values(X)
        )

        # Handle SHAP output for models where
        # shap_values may be returned as a list.
        if isinstance(
            shap_values,
            list
        ):

            shap_values = shap_values[0]

        shap_values = np.asarray(
            shap_values
        )

        # One prediction
        if shap_values.ndim == 2:

            values = shap_values[0]

        else:

            values = shap_values

        explanations = []

        for i, feature in enumerate(
            X.columns
        ):

            value = X.iloc[0][feature]

            impact = values[i]

            if impact > 0:

                direction = (
                    "increases forecast"
                )

            elif impact < 0:

                direction = (
                    "decreases forecast"
                )

            else:

                direction = "no significant impact"

            explanations.append({

                "feature": str(
                    feature
                ),

                "value": float(
                    value
                ),

                "shap_value": float(
                    impact
                ),

                "direction": direction
            })

        # Most influential features first
        explanations.sort(
            key=lambda x:
                abs(x["shap_value"]),
            reverse=True
        )

        return explanations

    def get_top_features(
        self,
        X,
        top_n=5
    ):
        """
        Return the most influential features.
        """

        explanations = (
            self.generate_explanation(X)
        )

        return explanations[:top_n]


def save_feature_importance(
    explainer,
    X,
    output_path
):
    """
    Save SHAP feature importance plot.
    """

    import matplotlib.pyplot as plt

    X = explainer.prepare_input(X)

    shap_values = explainer.explain(X)

    if isinstance(
        shap_values,
        list
    ):

        shap_values = shap_values[0]

    shap.summary_plot(
        shap_values,
        X,
        show=False
    )

    plt.tight_layout()

    plt.savefig(
        output_path,
        dpi=150,
        bbox_inches="tight"
    )

    plt.close()