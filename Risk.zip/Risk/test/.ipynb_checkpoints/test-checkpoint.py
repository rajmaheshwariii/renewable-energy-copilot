"""
Tests for Member 2 - Renewable Energy Risk Engine

Run from the project root:

    pytest tests/test_risk_engine.py -v

These tests verify:
    1. Energy gap calculation
    2. Shortage calculation
    3. Surplus calculation
    4. Energy risk
    5. Battery risk
    6. Uncertainty risk
    7. Backup risk
    8. Grid risk
    9. Condition classification
    10. Risk level classification
    11. Complete risk calculation
    12. Row-based risk calculation
    13. DataFrame risk calculation
"""


import pandas as pd
import pytest


# ============================================================
# IMPORT RISK ENGINE
# ============================================================

try:
    from src.member2_risk_explainability.risk_engine import (
        calculate_energy_gap,
        calculate_shortage,
        calculate_surplus,
        calculate_energy_risk,
        calculate_battery_risk,
        calculate_uncertainty_risk,
        calculate_backup_risk,
        calculate_grid_risk,
        classify_condition,
        classify_risk_level,
        calculate_risk,
        calculate_risk_from_row,
        add_risk_columns_to_dataframe,
    )

except ImportError:
    # Allows the tests to work if the test file is run
    # from inside the Member 2 directory.
    from risk_engine import (
        calculate_energy_gap,
        calculate_shortage,
        calculate_surplus,
        calculate_energy_risk,
        calculate_battery_risk,
        calculate_uncertainty_risk,
        calculate_backup_risk,
        calculate_grid_risk,
        classify_condition,
        classify_risk_level,
        calculate_risk,
        calculate_risk_from_row,
        add_risk_columns_to_dataframe,
    )


# ============================================================
# 1. ENERGY GAP TESTS
# ============================================================

def test_energy_gap_when_generation_equals_demand():
    """
    If generation equals demand, the energy gap should be zero.
    """

    result = calculate_energy_gap(
        forecast_kw=100,
        demand_kw=100
    )

    assert result == 0


def test_energy_gap_shortage():
    """
    If generation is lower than demand,
    the energy gap should be negative.
    """

    result = calculate_energy_gap(
        forecast_kw=70,
        demand_kw=100
    )

    assert result == -30


def test_energy_gap_surplus():
    """
    If generation is greater than demand,
    the energy gap should be positive.
    """

    result = calculate_energy_gap(
        forecast_kw=130,
        demand_kw=100
    )

    assert result == 30


# ============================================================
# 2. SHORTAGE TESTS
# ============================================================

def test_shortage_when_generation_is_lower():
    """
    Shortage should be demand - forecast.
    """

    result = calculate_shortage(
        forecast_kw=70,
        demand_kw=100
    )

    assert result == 30


def test_shortage_is_zero_when_generation_is_sufficient():
    """
    There should be no shortage when generation
    is greater than or equal to demand.
    """

    result = calculate_shortage(
        forecast_kw=120,
        demand_kw=100
    )

    assert result == 0


# ============================================================
# 3. SURPLUS TESTS
# ============================================================

def test_surplus_when_generation_is_higher():
    """
    Surplus should be forecast - demand.
    """

    result = calculate_surplus(
        forecast_kw=130,
        demand_kw=100
    )

    assert result == 30


def test_surplus_is_zero_when_generation_is_insufficient():
    """
    There should be no surplus when generation
    is lower than demand.
    """

    result = calculate_surplus(
        forecast_kw=80,
        demand_kw=100
    )

    assert result == 0


# ============================================================
# 4. ENERGY RISK TESTS
# ============================================================

def test_energy_risk_with_no_shortage():
    """
    No shortage should produce the minimum energy risk.
    """

    result = calculate_energy_risk(
        forecast_kw=120,
        demand_kw=100
    )

    assert result == 0


def test_energy_risk_with_shortage():
    """
    A 20% shortage should produce approximately
    20% energy risk.
    """

    result = calculate_energy_risk(
        forecast_kw=80,
        demand_kw=100
    )

    assert result == pytest.approx(20.0)


def test_energy_risk_is_capped_at_100():
    """
    Risk score should never exceed 100.
    """

    result = calculate_energy_risk(
        forecast_kw=0,
        demand_kw=100
    )

    assert 0 <= result <= 100


# ============================================================
# 5. BATTERY RISK TESTS
# ============================================================

def test_battery_risk_without_shortage():
    """
    When there is no shortage, battery risk should
    remain low according to the risk engine design.
    """

    result = calculate_battery_risk(
        battery_soc_pct=10,
        shortage_kw=0
    )

    assert result == 20


def test_battery_risk_during_shortage():
    """
    During shortage, lower battery SOC should produce
    higher battery risk.
    """

    result = calculate_battery_risk(
        battery_soc_pct=30,
        shortage_kw=20
    )

    assert result == pytest.approx(70.0)


def test_battery_risk_is_between_zero_and_hundred():
    """
    Battery risk must remain in the 0-100 range.
    """

    result = calculate_battery_risk(
        battery_soc_pct=50,
        shortage_kw=20
    )

    assert 0 <= result <= 100


# ============================================================
# 6. UNCERTAINTY RISK TESTS
# ============================================================

def test_uncertainty_risk_zero():
    """
    Zero uncertainty should result in zero uncertainty risk.
    """

    result = calculate_uncertainty_risk(
        uncertainty_pct=0
    )

    assert result == 0


def test_uncertainty_risk():
    """
    With MAX_UNCERTAINTY_FOR_100_RISK = 30,
    15% uncertainty should produce 50 risk.
    """

    result = calculate_uncertainty_risk(
        uncertainty_pct=15
    )

    assert result == pytest.approx(50.0)


def test_uncertainty_risk_is_capped():
    """
    Uncertainty risk should never exceed 100.
    """

    result = calculate_uncertainty_risk(
        uncertainty_pct=100
    )

    assert result == 100


# ============================================================
# 7. BACKUP RISK TESTS
# ============================================================

def test_backup_risk_when_no_shortage():
    """
    If there is no shortage, backup availability should
    not create a high risk.
    """

    result = calculate_backup_risk(
        shortage_kw=0,
        backup_available=False,
        backup_capacity_kw=0
    )

    assert result == 20


def test_backup_risk_unavailable_during_shortage():
    """
    An unavailable backup during shortage should
    produce maximum backup risk.
    """

    result = calculate_backup_risk(
        shortage_kw=20,
        backup_available=False,
        backup_capacity_kw=0
    )

    assert result == 100


def test_backup_risk_insufficient_capacity():
    """
    Available but insufficient backup should produce
    high backup risk.
    """

    result = calculate_backup_risk(
        shortage_kw=50,
        backup_available=True,
        backup_capacity_kw=20
    )

    assert result == 80


def test_backup_risk_sufficient_capacity():
    """
    Sufficient backup capacity should produce low backup risk.
    """

    result = calculate_backup_risk(
        shortage_kw=20,
        backup_available=True,
        backup_capacity_kw=30
    )

    assert result == 20


# ============================================================
# 8. GRID RISK TESTS
# ============================================================

def test_grid_risk_when_no_surplus():
    """
    Grid export is irrelevant when there is no surplus.
    """

    result = calculate_grid_risk(
        surplus_kw=0,
        grid_export_available=False,
        grid_export_limit_kw=0
    )

    assert result == 20


def test_grid_risk_when_export_is_unavailable():
    """
    Surplus with no grid export capability should
    produce maximum grid risk.
    """

    result = calculate_grid_risk(
        surplus_kw=50,
        grid_export_available=False,
        grid_export_limit_kw=0
    )

    assert result == 100


def test_grid_risk_when_export_limit_is_exceeded():
    """
    Surplus above the export limit should produce
    high grid risk.
    """

    result = calculate_grid_risk(
        surplus_kw=100,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    assert result == 80


def test_grid_risk_normal_export():
    """
    Surplus within the export limit should produce
    low grid risk.
    """

    result = calculate_grid_risk(
        surplus_kw=30,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    assert result == 20


# ============================================================
# 9. CONDITION CLASSIFICATION TESTS
# ============================================================

def test_condition_normal():
    """
    Generation approximately equal to demand
    should produce NORMAL condition.
    """

    result = classify_condition(
        forecast_kw=100,
        demand_kw=100,
        uncertainty_pct=5
    )

    assert result == "NORMAL"


def test_condition_shortage():
    """
    Generation below the shortage threshold
    should produce SHORTAGE.
    """

    result = classify_condition(
        forecast_kw=70,
        demand_kw=100,
        uncertainty_pct=5
    )

    assert result == "SHORTAGE"


def test_condition_surplus():
    """
    Generation above the surplus threshold
    should produce SURPLUS.
    """

    result = classify_condition(
        forecast_kw=130,
        demand_kw=100,
        uncertainty_pct=5
    )

    assert result == "SURPLUS"


def test_condition_high_uncertainty():
    """
    High uncertainty should take priority over
    shortage/surplus classification.
    """

    result = classify_condition(
        forecast_kw=70,
        demand_kw=100,
        uncertainty_pct=25
    )

    assert result == "HIGH_UNCERTAINTY"


# ============================================================
# 10. RISK LEVEL CLASSIFICATION TESTS
# ============================================================

def test_risk_level_low():
    """
    Risk below the moderate threshold should be LOW.
    """

    result = classify_risk_level(20)

    assert result == "LOW"


def test_risk_level_moderate():
    """
    Risk between moderate and high thresholds
    should be MODERATE.
    """

    result = classify_risk_level(40)

    assert result == "MODERATE"


def test_risk_level_high():
    """
    Risk between high and critical thresholds
    should be HIGH.
    """

    result = classify_risk_level(60)

    assert result == "HIGH"


def test_risk_level_critical():
    """
    Risk above the high threshold should be CRITICAL.
    """

    result = classify_risk_level(90)

    assert result == "CRITICAL"


# ============================================================
# 11. COMPLETE RISK CALCULATION TESTS
# ============================================================

def test_calculate_risk_returns_expected_keys():
    """
    Complete risk calculation should return all
    required Member 2 output fields.
    """

    result = calculate_risk(
        forecast_kw=80,
        demand_kw=100,
        battery_soc_pct=40,
        uncertainty_pct=10,
        backup_available=True,
        backup_capacity_kw=30,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    expected_keys = {
        "forecast_kw",
        "demand_kw",
        "energy_gap_kw",
        "shortage_kw",
        "surplus_kw",
        "battery_soc_pct",
        "uncertainty_pct",
        "condition",
        "risk_score",
        "risk_level",
        "risk_components",
        "risk_weights",
        "risk_reasons",
    }

    assert expected_keys.issubset(
        result.keys()
    )


def test_calculate_risk_shortage():
    """
    A forecast significantly below demand should
    produce a shortage condition.
    """

    result = calculate_risk(
        forecast_kw=50,
        demand_kw=100,
        battery_soc_pct=20,
        uncertainty_pct=5,
        backup_available=False,
        backup_capacity_kw=0,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    assert result["shortage_kw"] == 50
    assert result["surplus_kw"] == 0
    assert result["condition"] == "SHORTAGE"
    assert 0 <= result["risk_score"] <= 100


def test_calculate_risk_surplus():
    """
    A forecast significantly above demand should
    produce a surplus condition.
    """

    result = calculate_risk(
        forecast_kw=150,
        demand_kw=100,
        battery_soc_pct=70,
        uncertainty_pct=5,
        backup_available=True,
        backup_capacity_kw=50,
        grid_export_available=True,
        grid_export_limit_kw=100
    )

    assert result["shortage_kw"] == 0
    assert result["surplus_kw"] == 50
    assert result["condition"] == "SURPLUS"
    assert 0 <= result["risk_score"] <= 100


def test_calculate_risk_score_range():
    """
    Final risk score must always be between 0 and 100.
    """

    test_cases = [
        {
            "forecast_kw": 0,
            "demand_kw": 100,
            "battery_soc_pct": 0,
            "uncertainty_pct": 100,
            "backup_available": False,
            "backup_capacity_kw": 0,
            "grid_export_available": False,
            "grid_export_limit_kw": 0,
        },
        {
            "forecast_kw": 200,
            "demand_kw": 100,
            "battery_soc_pct": 100,
            "uncertainty_pct": 0,
            "backup_available": True,
            "backup_capacity_kw": 200,
            "grid_export_available": True,
            "grid_export_limit_kw": 200,
        },
    ]

    for case in test_cases:

        result = calculate_risk(**case)

        assert 0 <= result["risk_score"] <= 100


# ============================================================
# 12. ROW-BASED RISK TESTS
# ============================================================

def test_calculate_risk_from_row():
    """
    calculate_risk_from_row() should correctly convert
    a DataFrame row/dictionary into a risk result.
    """

    row = {
        "forecast_kw": 80,
        "demand_kw": 100,
        "battery_soc_pct": 40,
        "uncertainty_pct": 10,
        "backup_available": True,
        "backup_capacity_kw": 30,
        "grid_export_available": True,
        "grid_export_limit_kw": 50,
    }

    result = calculate_risk_from_row(row)

    assert result["forecast_kw"] == 80
    assert result["demand_kw"] == 100
    assert result["shortage_kw"] == 20
    assert 0 <= result["risk_score"] <= 100


def test_calculate_risk_from_row_with_generation_ac():
    """
    The risk engine should support generation_ac_kw
    as a fallback forecast column.
    """

    row = {
        "generation_ac_kw": 80,
        "demand_kw": 100,
        "battery_soc_pct": 50,
        "uncertainty_pct": 5,
        "backup_available": True,
        "backup_capacity_kw": 30,
        "grid_export_available": True,
        "grid_export_limit_kw": 50,
    }

    result = calculate_risk_from_row(row)

    assert result["forecast_kw"] == 80
    assert result["shortage_kw"] == 20


# ============================================================
# 13. DATAFRAME TESTS
# ============================================================

def test_add_risk_columns_to_dataframe():
    """
    The DataFrame function should add the required
    risk columns without removing the original columns.
    """

    df = pd.DataFrame({
        "forecast_kw": [100, 80, 150],
        "demand_kw": [100, 100, 100],
        "battery_soc_pct": [60, 40, 70],
        "uncertainty_pct": [5, 10, 5],
        "backup_available": [True, True, True],
        "backup_capacity_kw": [20, 30, 50],
        "grid_export_available": [True, True, True],
        "grid_export_limit_kw": [50, 50, 100],
    })

    result = add_risk_columns_to_dataframe(df)

    # Original columns should remain.
    assert "forecast_kw" in result.columns
    assert "demand_kw" in result.columns

    # Risk columns should be added.
    assert "energy_gap_kw" in result.columns
    assert "shortage_kw" in result.columns
    assert "surplus_kw" in result.columns
    assert "condition" in result.columns
    assert "risk_score" in result.columns
    assert "risk_level" in result.columns
    assert "risk_components" in result.columns
    assert "risk_reasons" in result.columns

    # Number of rows should remain unchanged.
    assert len(result) == 3


def test_dataframe_shortage_and_surplus_values():
    """
    Verify shortage and surplus calculations for
    multiple forecast rows.
    """

    df = pd.DataFrame({
        "forecast_kw": [80, 100, 150],
        "demand_kw": [100, 100, 100],
        "battery_soc_pct": [40, 50, 70],
        "uncertainty_pct": [5, 5, 5],
    })

    result = add_risk_columns_to_dataframe(df)

    assert result.iloc[0]["shortage_kw"] == 20
    assert result.iloc[0]["surplus_kw"] == 0

    assert result.iloc[1]["shortage_kw"] == 0
    assert result.iloc[1]["surplus_kw"] == 0

    assert result.iloc[2]["shortage_kw"] == 0
    assert result.iloc[2]["surplus_kw"] == 50


def test_dataframe_risk_scores_are_valid():
    """
    Every calculated risk score must be within 0-100.
    """

    df = pd.DataFrame({
        "forecast_kw": [0, 50, 100, 150, 200],
        "demand_kw": [100, 100, 100, 100, 100],
        "battery_soc_pct": [10, 20, 50, 70, 90],
        "uncertainty_pct": [30, 20, 10, 5, 0],
    })

    result = add_risk_columns_to_dataframe(df)

    assert (
        result["risk_score"]
        .between(0, 100)
        .all()
    )


# ============================================================
# 14. EDGE CASE TESTS
# ============================================================

def test_zero_demand_does_not_crash():
    """
    Zero demand should not cause a division-by-zero error.
    """

    result = calculate_risk(
        forecast_kw=100,
        demand_kw=0,
        battery_soc_pct=50,
        uncertainty_pct=5,
        backup_available=True,
        backup_capacity_kw=20,
        grid_export_available=True,
        grid_export_limit_kw=100
    )

    assert 0 <= result["risk_score"] <= 100


def test_negative_forecast_is_handled():
    """
    Negative forecast values should not cause the
    risk engine to return an invalid score.
    """

    result = calculate_risk(
        forecast_kw=-10,
        demand_kw=100,
        battery_soc_pct=50,
        uncertainty_pct=5,
        backup_available=True,
        backup_capacity_kw=20,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    assert 0 <= result["risk_score"] <= 100


def test_high_uncertainty_has_priority():
    """
    HIGH_UNCERTAINTY should be returned when uncertainty
    crosses the configured high-uncertainty threshold.
    """

    result = calculate_risk(
        forecast_kw=100,
        demand_kw=100,
        battery_soc_pct=50,
        uncertainty_pct=25,
        backup_available=True,
        backup_capacity_kw=20,
        grid_export_available=True,
        grid_export_limit_kw=50
    )

    assert result["condition"] == "HIGH_UNCERTAINTY"


# ============================================================
# FINAL TEST
# ============================================================

def test_complete_member2_pipeline():
    """
    Small end-to-end test for the Member 2 risk engine.

    It verifies that:
        forecast + demand
            ↓
        risk calculation
            ↓
        valid risk result
    """

    df = pd.DataFrame({
        "forecast_kw": [75, 100, 140],
        "demand_kw": [100, 100, 100],
        "battery_soc_pct": [30, 60, 80],
        "uncertainty_pct": [10, 5, 5],
        "backup_available": [True, True, True],
        "backup_capacity_kw": [50, 20, 50],
        "grid_export_available": [True, True, True],
        "grid_export_limit_kw": [50, 50, 100],
    })

    result = add_risk_columns_to_dataframe(df)

    # Three input rows should produce three output rows.
    assert len(result) == 3

    # Every row must have a valid risk score.
    assert result["risk_score"].between(
        0,
        100
    ).all()

    # Every row must have a condition.
    assert result["condition"].notna().all()

    # Every row must have a risk level.
    assert result["risk_level"].notna().all()